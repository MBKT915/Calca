
class InvalidOperation(Exception):
    pass


class InvalidParams(Exception):
    pass
